Gradle wrapper properties are included. Generate gradlew/gradlew.bat and wrapper JAR with `gradle wrapper --gradle-version 8.9` or let Android Studio configure Gradle.

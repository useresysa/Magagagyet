# Agent Tool Protocol

Модели не имеют прямого доступа к ОС. Приложение выполняет инструменты от их имени после проверки аргументов.

## Общий формат внутреннего вызова
`{ "tool": "file_read", "args": { "path": "src/Main.kt" } }`

Поддерживаемые проектом интерфейсы/планируемые диспетчером инструменты:
- `file_list(path)` — список файлов только внутри workspace.
- `file_read(path)` — чтение текстового файла.
- `file_write(path, content)` — запись в workspace.
- `zip_create(source, destination)` — создать ZIP.
- `zip_extract(archive, destination)` — распаковать с лимитами.
- `http_get(url)` — HTTP(S), публичные адреса, без private/loopback/link-local.
- `apk_analyze(uri)` — SHA-256, ZIP entries, permissions metadata.
- `delegate_to_agent(agent, task, context, error)` — координатор передаёт работу локальной модели.
- `run_build(command)` — не предоставлять произвольную shell-команду модели; запускать только allowlist-команды и с подтверждением пользователя.

## Ошибки
Передавать агенту точный exception class, HTTP status, безопасное сообщение и шаг, на котором произошёл сбой. Не передавать секреты, access token, приватные файлы или заголовки авторизации.

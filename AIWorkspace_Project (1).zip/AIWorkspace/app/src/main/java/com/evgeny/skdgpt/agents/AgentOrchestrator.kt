package com.evgeny.skdgpt.agents

import com.evgeny.skdgpt.network.GigaChatClient
import com.evgeny.skdgpt.network.OllamaClient

class AgentOrchestrator(
    private val giga: GigaChatClient,
    private val ollama: OllamaClient
) {
    data class AgentOutcome(val agent: String, val text: String, val usedCloudFallback: Boolean)

    suspend fun execute(userTask: String, availableModels: Set<String>): List<AgentOutcome> {
        val results = mutableListOf<AgentOutcome>()
        val roles = listOf(
            Triple("analyst", "deepseek-r1:1.5b", AgentPrompts.analyst),
            Triple("programmer", "qwen2.5-coder:3b", AgentPrompts.programmer),
            Triple("reviewer", "llama3.2:3b", AgentPrompts.reviewer)
        )
        var context = userTask
        for ((role, model, prompt) in roles) {
            val output = if (model in availableModels) {
                runCatching { ollama.chat(model, prompt, context) }.getOrElse { error ->
                    cloudFallback(role, context, "Локальная модель $model завершилась ошибкой: ${error.message}")
                        .also { results += AgentOutcome(role, it, true) }
                }
            } else {
                cloudFallback(role, context, "Модель $model не найдена в Ollama.")
                    .also { results += AgentOutcome(role, it, true) }
            }
            if (results.none { it.agent == role }) results += AgentOutcome(role, output, false)
            context += "\n\nРезультат $role:\n$output"
        }
        return results
    }

    private suspend fun cloudFallback(role: String, context: String, failure: String): String {
        val instruction = "Локальный агент $role недоступен. Диагностируй причину и выполни его роль самостоятельно. Ошибка: $failure\nКонтекст:\n$context"
        return giga.chat(listOf("system" to AgentPrompts.coordinator, "user" to instruction))
    }

    suspend fun coordinatorCanRepair(agent: String, error: String, task: String): String =
        giga.chat(listOf("system" to AgentPrompts.coordinator,
            "user" to "Агент $agent сообщил ошибку: $error. Объясни агенту причину и точную инструкцию исправления. Задача: $task"))
}

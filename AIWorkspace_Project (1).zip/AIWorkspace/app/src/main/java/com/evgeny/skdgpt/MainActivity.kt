package com.evgeny.skdgpt

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.evgeny.skdgpt.ui.WorkspaceViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { WorkspaceApp() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WorkspaceApp(vm: WorkspaceViewModel = viewModel()) {
    var tab by remember { mutableStateOf("Чат") }
    var input by remember { mutableStateOf("") }
    var settingsKey by remember { mutableStateOf("") }
    val tabs = listOf("Чат", "Агенты", "Инструменты", "Настройки")
    Scaffold(
        topBar = { TopAppBar(title = { Text("AI Workspace") }, actions = {
            IconButton(onClick = { vm.refreshOllama() }) { Icon(Icons.Default.Refresh, "Проверить Ollama") }
        }) },
        bottomBar = {
            NavigationBar {
                tabs.forEach { item ->
                    NavigationBarItem(selected = tab == item, onClick = { tab = item },
                        icon = { Icon(when(item) {
                            "Чат" -> Icons.Default.Chat
                            "Агенты" -> Icons.Default.Groups
                            "Инструменты" -> Icons.Default.Build
                            else -> Icons.Default.Settings
                        }, null) }, label = { Text(item) })
                }
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(12.dp)) {
            when(tab) {
                "Чат" -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AssistChip(onClick = { vm.useCloudFallback = true }, label = { Text("GigaChat fallback: ${if(vm.useCloudFallback) "ON" else "OFF"}") })
                        AssistChip(onClick = { vm.refreshOllama() }, label = { Text("Ollama: ${vm.ollamaStatus}") })
                    }
                    LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(vm.messages) { msg ->
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(msg.role, style = MaterialTheme.typography.labelSmall)
                                    Text(msg.content)
                                }
                            }
                        }
                    }
                    OutlinedTextField(input, { input = it }, Modifier.fillMaxWidth(), placeholder = { Text("Опиши задачу агентам…") })
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { val q=input; input=""; vm.send(q) }, enabled = input.isNotBlank() && !vm.busy) {
                            if(vm.busy) CircularProgressIndicator(Modifier.size(18.dp)) else Icon(Icons.Default.Send, null)
                            Spacer(Modifier.width(6.dp)); Text("Отправить")
                        }
                        OutlinedButton(onClick = { vm.cancelCurrent() }) { Text("Стоп") }
                    }
                }
                "Агенты" -> {
                    Text("Команда агентов", style = MaterialTheme.typography.titleLarge)
                    vm.agentDescriptions.forEach { (name, desc) ->
                        ListItem(headlineContent = { Text(name) }, supportingContent = { Text(desc) })
                        HorizontalDivider()
                    }
                    Text("Модели загружаются по требованию. Если Ollama недоступна или модель не найдена, координатор GigaChat анализирует проблему и продолжает доступными инструментами.")
                }
                "Инструменты" -> {
                    Text("Инструменты", style = MaterialTheme.typography.titleLarge)
                    listOf("Файлы и ZIP", "Песочница рабочей директории", "HTTP-клиент с SSRF-защитой", "APK-анализ: манифест, DEX, ресурсы, SHA-256", "Журнал действий", "Проверка локальных моделей").forEach {
                        ListItem(leadingContent = { Icon(Icons.Default.Extension, null) }, headlineContent = { Text(it) })
                    }
                    Text("Для файлов выберите документ через системный файловый диалог. Доступ ограничен выбранными пользователем URI.")
                }
                else -> {
                    Text("Настройки подключений", style = MaterialTheme.typography.titleLarge)
                    Text("GigaChat Authorization key (Basic)")
                    OutlinedTextField(settingsKey, { settingsKey = it }, Modifier.fillMaxWidth(), placeholder = { Text("Вставьте новый ключ") })
                    Button(onClick = { vm.saveGigaKey(settingsKey); settingsKey = "" }, enabled = settingsKey.isNotBlank()) { Text("Сохранить ключ") }
                    Text("Client ID: ${BuildConfigInfo.CLIENT_ID}")
                    Text("Scope: GIGACHAT_API_PERS")
                    Text("Ollama URL: ${vm.ollamaBaseUrl}")
                    OutlinedTextField(vm.ollamaBaseUrl, { vm.ollamaBaseUrl = it }, Modifier.fillMaxWidth())
                    Button(onClick = { vm.refreshOllama() }) { Text("Проверить модели") }
                    Text(vm.ollamaStatus)
                    Text("Ключ сохранён в Android EncryptedSharedPreferences/Keystore. Ранее опубликованный ключ рекомендуется отозвать и заменить.")
                }
            }
        }
    }
}

package com.evgeny.skdgpt.tools

import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object ZipTools {
    fun zip(source: File, destination: File) {
        ZipOutputStream(destination.outputStream().buffered()).use { out ->
            val base = source.parentFile ?: source
            source.walkTopDown().filter { it.isFile }.forEach { file ->
                val name = file.relativeTo(base).invariantSeparatorsPath
                out.putNextEntry(ZipEntry(name))
                file.inputStream().use { it.copyTo(out) }
                out.closeEntry()
            }
        }
    }
    fun unzip(zip: File, destination: File, maxEntries: Int = 5000, maxBytes: Long = 200L * 1024 * 1024) {
        destination.mkdirs()
        var entries = 0; var total = 0L
        ZipInputStream(zip.inputStream().buffered()).use { input ->
            while (true) {
                val entry = input.nextEntry ?: break
                require(++entries <= maxEntries) { "Too many ZIP entries" }
                val out = File(destination, entry.name).canonicalFile
                require(out.path.startsWith(destination.canonicalPath + File.separator) || out == destination.canonicalFile) {
                    "ZIP path traversal blocked"
                }
                if (!entry.isDirectory) {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { stream ->
                        val buffer = ByteArray(8192)
                        while (true) {
                            val n = input.read(buffer); if (n < 0) break
                            total += n; require(total <= maxBytes) { "ZIP expanded size limit exceeded" }
                            stream.write(buffer, 0, n)
                        }
                    }
                }
                input.closeEntry()
            }
        }
    }
}

package com.evgeny.skdgpt.network

import com.evgeny.skdgpt.data.OllamaModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MediaType.Companion.toMediaType
import org.json.JSONObject

class OllamaClient(var baseUrl: String = "http://127.0.0.1:11434") {
    suspend fun listModels(): List<OllamaModel> = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(baseUrl.trimEnd('/') + "/api/tags").get().build()
        Http.client.newCall(req).execute().use { r ->
            val raw = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw IllegalStateException("Ollama HTTP ${r.code}: $raw")
            val arr = JSONObject(raw).optJSONArray("models") ?: return@withContext emptyList()
            (0 until arr.length()).map { OllamaModel(arr.getJSONObject(it).optString("name")) }
        }
    }

    suspend fun chat(model: String, system: String, prompt: String): String = withContext(Dispatchers.IO) {
        val body = JSONObject().put("model", model).put("stream", false)
            .put("messages", org.json.JSONArray()
                .put(JSONObject().put("role", "system").put("content", system))
                .put(JSONObject().put("role", "user").put("content", prompt)))
        val req = Request.Builder().url(baseUrl.trimEnd('/') + "/api/chat")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        Http.client.newCall(req).execute().use { r ->
            val raw = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw IllegalStateException("Ollama HTTP ${r.code}: $raw")
            JSONObject(raw).getJSONObject("message").optString("content")
        }
    }
}

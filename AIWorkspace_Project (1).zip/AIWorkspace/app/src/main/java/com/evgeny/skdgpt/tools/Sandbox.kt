package com.evgeny.skdgpt.tools

import java.io.File

/** App-private workspace only. This is not Docker or a security boundary against the app itself. */
class Sandbox(private val root: File) {
    init { root.mkdirs() }
    fun resolve(relative: String): File {
        require(!relative.startsWith("/") && !relative.contains("\\"))
        val target = File(root, relative).canonicalFile
        require(target.path == root.canonicalPath || target.path.startsWith(root.canonicalPath + File.separator)) {
            "Path escapes workspace"
        }
        return target
    }
    fun list(relative: String = "."): List<String> = resolve(relative).list()?.toList().orEmpty()
    fun read(relative: String): String = resolve(relative).readText()
    fun write(relative: String, content: String) {
        val file = resolve(relative); file.parentFile?.mkdirs(); file.writeText(content)
    }
    fun delete(relative: String): Boolean = resolve(relative).delete()
}

package com.evgeny.skdgpt.network

import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

object Http {
    val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .callTimeout(150, TimeUnit.SECONDS)
        .followRedirects(false)
        .build()
}

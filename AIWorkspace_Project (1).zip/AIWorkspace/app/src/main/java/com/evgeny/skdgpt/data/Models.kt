package com.evgeny.skdgpt.data

data class ChatMessage(val role: String, val content: String)
data class OllamaModel(val name: String)
data class AgentSpec(val id: String, val model: String, val role: String, val systemPrompt: String)
data class ToolResult(val ok: Boolean, val output: String, val error: String? = null)

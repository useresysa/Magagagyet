package com.evgeny.skdgpt
object BuildConfigInfo {
    const val CLIENT_ID = "01a1b93d-fbc4-790e-81e7-03550b04e9e9"
    const val SCOPE = "GIGACHAT_API_PERS"
    // Не встраивать Authorization key в APK. Введите перевыпущенный ключ в настройках.
}

package com.evgeny.skdgpt.tools

import android.content.Context
import android.net.Uri
import android.content.pm.PackageManager
import android.os.Build
import java.security.MessageDigest
import java.util.zip.ZipFile

class ApkAnalyzer(private val context: Context) {
    fun analyze(uri: Uri): String {
        val temp = kotlin.io.path.createTempFile(suffix = ".apk").toFile()
        try {
            context.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Cannot open APK URI" }.copyTo(temp.outputStream())
            }
            val digest = MessageDigest.getInstance("SHA-256").digest(temp.readBytes()).joinToString("") { "%02x".format(it) }
            val entries = ZipFile(temp).use { zip -> zip.entries().asSequence().map { it.name }.toList() }
            val manifest = if (Build.VERSION.SDK_INT >= 33)
                context.packageManager.getPackageArchiveInfo(temp.absolutePath, PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong()))
            else @Suppress("DEPRECATION") context.packageManager.getPackageArchiveInfo(temp.absolutePath, PackageManager.GET_PERMISSIONS)
            return buildString {
                appendLine("SHA-256: $digest")
                appendLine("Entries: ${entries.size}")
                appendLine("DEX: ${entries.filter { it.matches(Regex("classes[0-9]*\\.dex")) }}")
                appendLine("Native libraries: ${entries.filter { it.startsWith("lib/") }.take(100)}")
                appendLine("Assets: ${entries.filter { it.startsWith("assets/") }.take(100)}")
                appendLine("Manifest permissions: ${manifest?.requestedPermissions?.joinToString() ?: "not parsed"}")
                appendLine("Manifest binary XML and Smali decompilation require dedicated parsers/decompiler; not falsely reported as completed.")
                appendLine("Potential URLs: ${entries.filter { it.endsWith(".json") || it.endsWith(".xml") }.take(100)}")
            }
        } finally { temp.delete() }
    }
}

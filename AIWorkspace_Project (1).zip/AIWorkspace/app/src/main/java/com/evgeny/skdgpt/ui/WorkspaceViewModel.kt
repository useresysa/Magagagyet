package com.evgeny.skdgpt.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.evgeny.skdgpt.data.ChatMessage
import com.evgeny.skdgpt.network.GigaChatClient
import com.evgeny.skdgpt.network.OllamaClient
import com.evgeny.skdgpt.security.SecretStore
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class WorkspaceViewModel(app: Application) : AndroidViewModel(app) {
    private val secrets = SecretStore(app)
    private val giga = GigaChatClient { secrets.getGigaKey() }
    val ollama = OllamaClient()
    var ollamaBaseUrl: String
        get() = ollama.baseUrl
        set(value) { ollama.baseUrl = value.trim() }
    var ollamaStatus = "Не проверено"
        private set
    var busy = false
        private set
    var useCloudFallback = true
    val messages = mutableListOf<ChatMessage>()
    private var active: Job? = null
    val agentDescriptions = listOf(
        "GigaChat" to "Координатор, fallback, диагностика и распределение задач",
        "DeepSeek R1 1.5B" to "Аналитика и планирование",
        "Qwen2.5 Coder 3B" to "Основной программист",
        "Llama 3.2 3B" to "Рецензирование и поиск ошибок",
        "Qwen2.5 Coder 1.5B" to "Быстрые исправления"
    )

    fun saveGigaKey(key: String) = secrets.putGigaKey(key)
    fun refreshOllama() {
        active = viewModelScope.launch {
            ollamaStatus = "Проверка…"
            ollamaStatus = runCatching {
                val models = ollama.listModels()
                "Доступно моделей: ${models.size} — ${models.joinToString { it.name }}"
            }.getOrElse { "Ollama недоступна: ${it.message}" }
        }
    }
    fun send(text: String) {
        if (text.isBlank() || busy) return
        messages += ChatMessage("Вы", text)
        active = viewModelScope.launch {
            busy = true
            try {
                val models = runCatching { ollama.listModels().map { it.name }.toSet() }.getOrDefault(emptySet())
                val answer = if (models.isEmpty() || useCloudFallback) {
                    giga.chat(listOf("system" to com.evgeny.skdgpt.agents.AgentPrompts.coordinator, "user" to text))
                } else {
                    val orchestrator = com.evgeny.skdgpt.agents.AgentOrchestrator(giga, ollama)
                    orchestrator.execute(text, models).joinToString("\n\n") { "[${it.agent}]\n${it.text}" }
                }
                messages += ChatMessage("AI Workspace", answer)
            } catch (e: Exception) {
                messages += ChatMessage("Ошибка", e.message ?: "Неизвестная ошибка")
            } finally { busy = false }
        }
    }
    fun cancelCurrent() { active?.cancel(); busy = false }
}

package com.evgeny.skdgpt.tools

import com.evgeny.skdgpt.network.Http
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.net.InetAddress
import java.net.URL

class SafeHttpTool {
    suspend fun get(urlText: String): String = withContext(Dispatchers.IO) {
        val url = URL(urlText)
        require(url.protocol == "https" || url.protocol == "http") { "Only HTTP(S) is allowed" }
        val host = url.host.lowercase()
        require(host != "localhost" && !host.endsWith(".localhost")) { "Local hosts are blocked" }
        val addresses = InetAddress.getAllByName(host)
        require(addresses.isNotEmpty() && addresses.none {
            it.isAnyLocalAddress || it.isLoopbackAddress || it.isLinkLocalAddress ||
            it.isSiteLocalAddress || it.hostAddress.startsWith("169.254.")
        }) { "Private/internal network targets are blocked" }
        val request = Request.Builder().url(url).get().build()
        Http.client.newCall(request).execute().use { response ->
            require(response.code in 200..299) { "HTTP ${response.code}" }
            response.body?.string().orEmpty().take(1_000_000)
        }
    }
}

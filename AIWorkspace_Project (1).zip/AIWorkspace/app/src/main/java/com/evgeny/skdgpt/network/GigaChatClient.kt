package com.evgeny.skdgpt.network

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MediaType.Companion.toMediaType
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class GigaChatClient(private val keyProvider: () -> String?) {
    private val mutex = Mutex()
    @Volatile private var accessToken: String? = null
    @Volatile private var expiresAt: Long = 0L

    suspend fun models(): String = withContext(Dispatchers.IO) {
        val req = Request.Builder().url("https://api.giga.chat/v1/models")
            .header("Accept", "application/json")
            .header("Authorization", "Bearer ${token()}")
            .get().build()
        Http.client.newCall(req).execute().use { it.body?.string().orEmpty().also {
            if (!it.isSuccessful) throw IllegalStateException("GigaChat models HTTP ${it.code}: $it")
        } }
    }

    private suspend fun token(force: Boolean = false): String = mutex.withLock {
        if (!force && accessToken != null && System.currentTimeMillis() < expiresAt - 60_000) return@withLock accessToken!!
        val basic = keyProvider()?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("Добавьте Authorization key в настройках.")
        val body = FormBody.Builder().add("scope", "GIGACHAT_API_PERS").build()
        val req = Request.Builder().url("https://ngw.devices.sberbank.ru:9443/api/v2/oauth")
            .header("Content-Type", "application/x-www-form-urlencoded")
            .header("Accept", "application/json")
            .header("RqUID", UUID.randomUUID().toString())
            .header("Authorization", "Basic $basic").post(body).build()
        val raw = Http.client.newCall(req).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IllegalStateException("OAuth HTTP ${response.code}: $text")
            text
        }
        val json = JSONObject(raw)
        accessToken = json.getString("access_token")
        expiresAt = json.optLong("expires_at", System.currentTimeMillis() + 1_700_000)
        accessToken!!
    }

    suspend fun chat(messages: List<Pair<String, String>>, model: String = "GigaChat") : String = withContext(Dispatchers.IO) {
        suspend fun perform(force: Boolean): okhttp3.Response {
            val token = token(force)
            val arr = JSONArray()
            messages.forEach { (role, content) ->
                arr.put(JSONObject().put("role", role).put("content", content))
            }
            val payload = JSONObject().put("model", model).put("messages", arr)
                .put("temperature", 0.3).put("stream", false)
            val req = Request.Builder().url("https://api.giga.chat/v1/chat/completions")
                .header("Authorization", "Bearer $token")
                .header("Content-Type", "application/json")
                .post(payload.toString().toRequestBody("application/json".toMediaType())).build()
            return Http.client.newCall(req).execute()
        }
        var response = perform(false)
        if (response.code == 401) { response.close(); response = perform(true) }
        response.use {
            val raw = it.body?.string().orEmpty()
            if (!it.isSuccessful) throw IllegalStateException("GigaChat HTTP ${it.code}: $raw")
            JSONObject(raw).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
        }
    }
}
